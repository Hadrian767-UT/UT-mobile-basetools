draw_set_alpha(0.5);
draw_set_font(th_ui);
draw_set_halign(fa_left);
draw_set_valign(fa_top);
var iColor = make_color_rgb(229, 123, 158);
var i_green = merge_color(c_green, iColor, 0);
var i_orange = merge_color(c_orange, iColor, 0);
var i_aqua = merge_color(c_aqua, iColor, 0);
draw_roundrect_color_ext(380, 0, 460, 20, 20, 20, c_green, c_green, 0);
draw_set_alpha(0.7);
i = 0;

while (i < 2)
{
    draw_roundrect_color_ext(382 + i, 2 + i, 458 - i, 18 - i, 20, 20, i_green, i_green, 1);
    i += 0.1;
}

draw_text_color(415, 1, "C", c_white, c_white, c_white, c_white, 0.8);
draw_set_alpha(0.5);
draw_roundrect_color_ext(460, 0, 540, 40, 20, 20, c_orange, c_orange, 0);
draw_set_alpha(0.7);
i = 0;

while (i < 2)
{
    draw_roundrect_color_ext(462 + i, 2 + i, 538 - i, 38 - i, 20, 20, i_orange, i_orange, 1);
    i += 0.1;
}

draw_text_color(480, 10, "Shift", c_white, c_white, c_white, c_white, 1);
draw_set_alpha(0.5);
draw_roundrect_color_ext(540, 0, 620, 40, 20, 20, c_aqua, c_aqua, 0);
draw_set_alpha(0.7);
i = 0;

while (i < 2)
{
    draw_roundrect_color_ext(542 + i, 2 + i, 618 - i, 38 - i, 20, 20, i_aqua, i_aqua, 1);
    i += 0.1;
}

draw_text_color(558, 10, "Enter", c_white, c_white, c_white, c_white, 1);
draw_set_alpha(1);
ca++;
HSV = make_color_hsv(ca % 255, 255, 255);

if (global.debug_legally == 1)
{
    draw_set_alpha(0.5);
    draw_roundrect_color_ext(10, 90, 90, 130, 20, 20, HSV, HSV, 0);
    draw_set_alpha(0.7);
    i = 0;
    
    while (i < 2)
    {
        draw_roundrect_color_ext(12 + i, 92 + i, 88 - i, 128 - i, 20, 20, HSV, HSV, 1);
        i += 0.1;
    }
    
    draw_text_color(21, 100, "Debug", HSV, HSV, HSV, HSV, 0.5);
}

draw_set_alpha(0.5);
draw_roundrect_color_ext(10, 50, 90, 80, 20, 20, HSV, HSV, 0);
draw_set_alpha(0.7);
i = 0;

while (i < 2)
{
    draw_roundrect_color_ext(12 + i, 52 + i, 88 - i, 78 - i, 20, 20, HSV, HSV, 1);
    i += 0.1;
}

draw_text_color(22, 56, "??????", HSV, HSV, HSV, HSV, 0.5);
draw_set_alpha(0.5);
draw_roundrect_color_ext(10, 0, 92, 40, 20, 20, HSV, HSV, 0);
draw_set_alpha(0.7);
i = 0;

while (i < 2)
{
    draw_roundrect_color_ext(12 + i, 2 + i, 90 - i, 38 - i, 20, 20, HSV, HSV, 1);
    i += 0.1;
}

draw_text_color(20, 10, "Restart", HSV, HSV, HSV, HSV, 0.5);
draw_set_alpha(1);
draw_sprite_ext(spr_mobilekey, 0, 140, 360, 2, 2, 0, c_white, 0.41);
draw_sprite_ext(spr_mobilekey, 0, 500, 360, 2, 2, 0, c_white, 0.41);
