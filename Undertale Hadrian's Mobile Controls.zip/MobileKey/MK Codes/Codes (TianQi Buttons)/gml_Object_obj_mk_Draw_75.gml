draw_set_alpha(0.5)
draw_set_font(th_ui)
draw_set_halign(fa_left)
draw_set_valign(fa_top)
var iColor = make_color_rgb(229, 123, 158)
var i_green = merge_color(c_green, iColor, 0)
var i_orange = merge_color(c_orange, iColor, 0)
var i_aqua = merge_color(c_aqua, iColor, 0)
draw_roundrect_color_ext(380, 420, 460, 440, 20, 20, i_green, i_green, 0)
draw_set_alpha(0.7)
for (i = 0; i < 2; i += 0.1)
    draw_roundrect_color_ext((382 + i), (422 + i), (458 - i), (438 - i), 20, 20, i_green, i_green, 1)
draw_text_color(415, 420, "C", c_white, c_white, c_white, c_white, 0.8)
draw_set_alpha(0.5)
draw_roundrect_color_ext(460, 400, 540, 440, 20, 20, i_orange, i_orange, 0)
draw_set_alpha(0.7)
for (i = 0; i < 2; i += 0.1)
    draw_roundrect_color_ext((462 + i), (402 + i), (538 - i), (438 - i), 20, 20, i_orange, i_orange, 1)
draw_text_color(480, 410, "Shift", c_white, c_white, c_white, c_white, 0.8)
draw_set_alpha(0.5)
draw_roundrect_color_ext(540, 400, 620, 440, 20, 20, i_aqua, i_aqua, 0)
draw_set_alpha(0.7)
for (i = 0; i < 2; i += 0.1)
    draw_roundrect_color_ext((542 + i), (402 + i), (618 - i), (438 - i), 20, 20, i_aqua, i_aqua, 1)
draw_text_color(558, 410, "Enter", c_white, c_white, c_white, c_white, 0.8)
draw_set_alpha(1)
ca++
HSV = make_color_hsv((ca % 255), 255, 255)
if (global.debug_legally == 1)
{
    draw_set_alpha(0.5)
    i = 0
    draw_roundrect_color_ext(540, 0, 620, 40, 20, 20, HSV, HSV, 0)
    while (i < 2)
    {
        draw_roundrect_color_ext((542 + i), (2 + i), (618 - i), (38 - i), 20, 20, HSV, HSV, 1)
        i += 0.1
    }
    draw_text_color(550, 10, "Debug", HSV, HSV, HSV, HSV, 0.5)
}
draw_set_alpha(0.5)
i = 0
draw_roundrect_color_ext(540, 50, 620, 80, 20, 20, HSV, HSV, 0)
while (i < 2)
{
    draw_roundrect_color_ext((542 + i), (52 + i), (618 - i), (78 - i), 20, 20, HSV, HSV, 1)
    i += 0.1
}
draw_text_color(551, 56, "??????", HSV, HSV, HSV, HSV, 0.5)
draw_set_alpha(0.5)
draw_roundrect_color_ext(10, 0, 92, 40, 20, 20, HSV, HSV, 0)
draw_set_alpha(0.7)
for (i = 0; i < 2; i += 0.1)
    draw_roundrect_color_ext((12 + i), (2 + i), (90 - i), (38 - i), 20, 20, HSV, HSV, 1)
draw_text_color(20, 10, "Restart", HSV, HSV, HSV, HSV, 0.5)
draw_set_alpha(1)
draw_sprite_ext(spr_mobilekey, 0, 140, 360, 2, 2, 0, c_white, 0.41)
