draw_set_alpha(0.5);
draw_set_font(DFPKuoTaiBeiW4);
draw_set_halign(fa_left);
draw_set_valign(fa_top);
draw_roundrect_color(380, 420, 460, 440, 32768, 32768, 1);
draw_set_alpha(0.8);
draw_text_color(415, 420, "C", c_green, c_green, c_green, c_green, 1);
draw_set_alpha(0.5);
draw_roundrect_color(460, 400, 540, 440, 4235519, 4235519, 1);
draw_set_alpha(0.8);
draw_text_color(475, 410, "Shift", c_orange, c_orange, c_orange, c_orange, 1);
draw_set_alpha(0.5);
draw_roundrect_color(540, 400, 620, 440, 16776960, 16776960, 1);
draw_set_alpha(0.8);
draw_text_color(555, 410, "Enter", c_aqua, c_aqua, c_aqua, c_aqua, 1);

if (global.debug_legally == 1)
{
    draw_set_alpha(0.5);
    draw_roundrect_color(540, 0, 620, 40, c_rainbow, c_rainbow, 1);
    draw_set_alpha(0.8);
    draw_text_color(550, 10, "Debug", c_rainbow, c_rainbow, c_rainbow, c_rainbow, 1);
}

draw_set_alpha(0.5);
draw_roundrect_color(540, 50, 620, 80, c_rainbow, c_rainbow, 1);
draw_set_alpha(0.8);
draw_text_color(551, 56, "??????", c_rainbow, c_rainbow, c_rainbow, c_rainbow, 1);
draw_set_alpha(0.5);
draw_roundrect_color(90, -1, 10, 40, c_rainbow, c_rainbow, 1);
draw_set_alpha(0.8);
draw_text_color(18, 10, "Restart", c_rainbow, c_rainbow, c_rainbow, c_rainbow, 1);
draw_set_alpha(1);
draw_sprite_ext(spr_mobilekey, 0, 140, 360, 2, 2, 0, c_white, 0.41);
awa += 1.45;
c_rainbow = make_color_hsv(awa % 223, 255, 200);
