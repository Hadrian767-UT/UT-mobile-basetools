_m = 1;

if (_mb_d == 1)
{
    var _dxr = device_mouse_x_to_gui(rl) - 495;
    var _dyr = device_mouse_y_to_gui(rl) - 365;
    var _dar = point_direction(0, 0, _dxr, _dyr);
    
    if (_dar >= 292.5 || _dar <= 67.5)
    {
        cdd = 0.5;
        
        if (_ak_r == 0)
            _ak_r = 68;
        else
            _ak_copy = 68;
    }
    
    if (device_mouse_x_to_gui(rl) >= (room_width / 2))
    {
        if (_dar >= 22.5 && _dar <= 157.5)
        {
            cw = 0.5;
            
            if (_ak_r == 0)
                _ak_r = 87;
            else
                _ak_copy = 87;
        }
    }
    
    if (device_mouse_x_to_gui(rl) >= (room_width / 2))
    {
        if (_dar >= 112.5 && _dar <= 247.5)
        {
            caa = 0.5;
            
            if (_ak_r == 0)
                _ak_r = 65;
            else
                _ak_copy = 65;
        }
    }
    
    if (_dar >= 202.5 && _dar <= 337.5)
    {
        cs = 0.5;
        
        if (_ak_r == 0)
            _ak_r = 83;
        else
            _ak_copy = 83;
    }
}

var _dx = device_mouse_x_to_gui(i) - 140;
var _dy = device_mouse_y_to_gui(i) - 360;
var _da = point_direction(0, 0, _dx, _dy);

if (_mb_d == 1)
{
    if (device_mouse_x_to_gui(i) <= (room_width / 2))
    {
        if (_da >= 292.5 || _da <= 67.5)
        {
            cr = 0.5;
            
            if (_ak == 0)
                _ak = 39;
            else
                _ak2 = 39;
        }
    }
}
else if (_da >= 292.5 || _da <= 67.5)
{
    cr = 0.5;
    
    if (_ak == 0)
        _ak = 39;
    else
        _ak2 = 39;
}

if (device_mouse_x_to_gui(i) <= (room_width / 2))
{
    if (_da >= 22.5 && _da <= 157.5)
    {
        cu = 0.5;
        
        if (_ak == 0)
            _ak = 38;
        else
            _ak2 = 38;
    }
}

if (_da >= 112.5 && _da <= 247.5)
{
    cl = 0.5;
    
    if (_ak == 0)
        _ak = 37;
    else
        _ak2 = 37;
}

if (_da >= 202.5 && _da <= 337.5)
{
    cd = 0.5;
    
    if (_ak == 0)
        _ak = 40;
    else
        _ak2 = 40;
}
