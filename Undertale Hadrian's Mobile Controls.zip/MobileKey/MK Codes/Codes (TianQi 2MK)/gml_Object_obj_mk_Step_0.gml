cu = 1;
cd = 1;
cl = 1;
cr = 1;
cz = 1;
cx = 1;
cg = 1;
cv = 1;
cm = 1;
cd_key_state = 1;
cF = 1;
cw = 1;
caa = 1;
cs = 1;
cdd = 1;
_m = 0;

for (rr = 0; rr < 2; rr++)
{
    rl = rr;
    
    if (_mb_d == 1)
    {
        var _dxr = device_mouse_x_to_gui(rl) - 495;
        var _dyr = device_mouse_y_to_gui(rl) - 365;
        var _dar = point_direction(0, 0, _dxr, _dyr);
        
        if (_dar >= 292.5 || _dar <= 67.5)
        {
            cdd = 0.5;
            
            if (_ak_r == 0)
                _ak_r = 68;
            else
                _ak_copy = 68;
        }
        
        if (device_mouse_x_to_gui(rl) >= (room_width / 2))
        {
            if (_dar >= 22.5 && _dar <= 157.5)
            {
                cw = 0.5;
                
                if (_ak_r == 0)
                    _ak_r = 87;
                else
                    _ak_copy = 87;
            }
        }
        
        if (device_mouse_x_to_gui(rl) >= (room_width / 2))
        {
            if (_dar >= 112.5 && _dar <= 247.5)
            {
                caa = 0.5;
                
                if (_ak_r == 0)
                    _ak_r = 65;
                else
                    _ak_copy = 65;
            }
        }
        
        if (_dar >= 202.5 && _dar <= 337.5)
        {
            cs = 0.5;
            
            if (_ak_r == 0)
                _ak_r = 83;
            else
                _ak_copy = 83;
        }
    }
}

for (i = 0; i < 4; i++)
{
    _ak = 0;
    _ak_copy = 0;
    _ak_r = 0;
    
    if (device_mouse_check_button(i, mb_left))
    {
        mouseX = device_mouse_x_to_gui(i);
        mouseY = device_mouse_y_to_gui(i);
        Xegui = device_mouse_x(i);
        
        if (_mb_d == 1)
        {
            if (room == undefined)
            {
                if (mouseX >= 560 && mouseY <= 40 && Xegui < room_width)
                {
                    cz = 0.5;
                    _ak = 90;
                }
            }
            else if (mouseX >= 560 && mouseY <= 40)
            {
                cz = 0.5;
                _ak = 90;
            }
            else if (global._is_debug == 1 && mouseX <= 92 && mouseY <= 90 && mouseY >= 50)
            {
                cd_key_state = 0.5;
                _ak_copy = 84;
            }
            else if (mouseX >= 480 && mouseX <= 540 && mouseY <= 40)
            {
                cx = 0.5;
                _ak = 88;
            }
            else if (mouseX >= 400 && mouseX <= 460 && mouseY <= 40)
            {
                cg = 0.5;
                _ak = 83;
            }
            else if (global._is_debug == 1 && mouseX >= 10 && mouseX <= 92 && mouseY >= 100 && mouseY <= 140)
            {
                cF = 0.5;
                _ak = 70;
            }
            else if (mouseX >= 102 && mouseY >= 0 && mouseX < 194 && mouseY <= 40)
            {
                cv = 0.5;
                _ak = 86;
            }
            else if (mouseX >= 10 && mouseX <= 92 && mouseY >= 0 && mouseY <= 40)
            {
                cm = 0.5;
                _ak = 77;
            }
            else if (!_m)
            {
                event_user(0);
            }
        }
        else if (room == undefined)
        {
            if (mouseX >= 560 && mouseY >= 40 && Xegui < room_width)
            {
                cz = 0.5;
                _ak = 90;
            }
        }
        else if (mouseX >= 560)
        {
            cz = 0.5;
            _ak = 90;
        }
        else if (global._is_debug == 1 && mouseX <= 92 && mouseY <= 90 && mouseY >= 50)
        {
            cd_key_state = 0.5;
            _ak_copy = 84;
        }
        else if (mouseX >= 480 && mouseX <= 540)
        {
            cx = 0.5;
            _ak = 88;
        }
        else if (mouseX >= 400 && mouseX <= 460)
        {
            cg = 0.5;
            _ak = 83;
        }
        else if (global._is_debug == 1 && mouseX >= 10 && mouseX <= 92 && mouseY >= 100 && mouseY <= 140)
        {
            cF = 0.5;
            _ak = 70;
        }
        else if (mouseX >= 102 && mouseY >= 0 && mouseX < 194 && mouseY <= 40)
        {
            cv = 0.5;
            _ak = 86;
        }
        else if (mouseX >= 10 && mouseX <= 90 && mouseY >= 0 && mouseY <= 40)
        {
            cm = 0.5;
            _ak = 77;
        }
        else if (!_m)
        {
            event_user(0);
        }
    }
    
    if (device_mouse_check_button_pressed(i, mb_left))
    {
        if (_ak != 0)
        {
            if (keyboard_check(_ak))
            {
                keyboard_key_release(_ak);
                keyboard_key_press(_ak);
            }
        }
        
        if (_ak_r != 0)
        {
            if (keyboard_check(_ak_r))
            {
                keyboard_key_release(_ak_r);
                keyboard_key_press(_ak_r);
            }
        }
        
        if (_ak_copy != 0)
        {
            if (keyboard_check(_ak_copy))
            {
                keyboard_key_release(_ak_copy);
                keyboard_key_press(_ak_copy);
            }
        }
    }
}

if (cz == 0.5 && !keyboard_check(ord("Z")))
    keyboard_key_press(ord("Z"));

if (cx == 0.5 && !keyboard_check(ord("X")))
    keyboard_key_press(ord("X"));

if (cg == 0.5 && !keyboard_check(ord("S")))
    keyboard_key_press(ord("S"));

if (cv == 0.5 && !keyboard_check(ord("V")))
    keyboard_key_press(ord("V"));

if (cm == 0.5 && !keyboard_check(ord("M")))
    keyboard_key_press(ord("M"));

if (cd_key_state == 0.5 && !keyboard_check(ord("T")))
    keyboard_key_press(ord("T"));

if (cF == 0.5 && !keyboard_check(ord("F")))
    keyboard_key_press(ord("F"));

if (cr == 0.5 && !keyboard_check(vk_right))
    keyboard_key_press(vk_right);

if (cu == 0.5 && !keyboard_check(vk_up))
    keyboard_key_press(vk_up);

if (cl == 0.5 && !keyboard_check(vk_left))
    keyboard_key_press(vk_left);

if (cd == 0.5 && !keyboard_check(vk_down))
    keyboard_key_press(vk_down);

if (cdd == 0.5 && !keyboard_check(ord("D")))
    keyboard_key_press(ord("D"));

if (cw == 0.5 && !keyboard_check(ord("W")))
    keyboard_key_press(ord("W"));

if (caa == 0.5 && !keyboard_check(ord("A")))
    keyboard_key_press(ord("A"));

if (cs == 0.5 && !keyboard_check(ord("S")))
    keyboard_key_press(ord("S"));

if (cz == 1 && keyboard_check(ord("Z")))
    keyboard_key_release(ord("Z"));

if (cx == 1 && keyboard_check(ord("X")))
    keyboard_key_release(ord("X"));

if (cg == 1 && keyboard_check(ord("S")))
    keyboard_key_release(ord("S"));

if (cv == 1 && keyboard_check(ord("V")))
    keyboard_key_release(ord("V"));

if (cm == 1 && keyboard_check(ord("M")))
    keyboard_key_release(ord("M"));

if (cd_key_state == 1 && keyboard_check(ord("T")))
    keyboard_key_release(ord("T"));

if (cF == 1 && keyboard_check(ord("F")))
    keyboard_key_release(ord("F"));

if (cr == 1 && keyboard_check(vk_right))
    keyboard_key_release(vk_right);

if (cu == 1 && keyboard_check(vk_up))
    keyboard_key_release(vk_up);

if (cl == 1 && keyboard_check(vk_left))
    keyboard_key_release(vk_left);

if (cd == 1 && keyboard_check(vk_down))
    keyboard_key_release(vk_down);

if (cdd == 1 && keyboard_check(ord("D")))
    keyboard_key_release(ord("D"));

if (cw == 1 && keyboard_check(ord("A")))
    keyboard_key_release(ord("W"));

if (caa == 1 && keyboard_check(ord("A")))
    keyboard_key_release(ord("A"));

if (cs == 1 && keyboard_check(ord("S")))
    keyboard_key_release(ord("S"));
