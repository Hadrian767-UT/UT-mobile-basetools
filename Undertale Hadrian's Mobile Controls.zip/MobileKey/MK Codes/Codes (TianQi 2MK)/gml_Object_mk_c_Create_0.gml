if (!file_exists("Android.ini"))
    show_error("file 'Android.ini' not exists", 1);

ini_open("Android.ini");
var debug = ini_read_string("Game", "Debug", "False");

if (debug == "True")
    global._is_debug = 1;
else
    global._is_debug = 0;

ini_close();
global.isFeatureEnabled = 0;
col = 0;
depth = -8000;
