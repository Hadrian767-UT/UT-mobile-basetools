if (_mb_d == 1)
{
    _mb_d = 0;
    c_mb_d = 16777215;
    audio_play_sound(snd_change_mk, 10, false);
}
else if (_mb_d == 0)
{
    _mb_d = 1;
    c_mb_d = 255;
    audio_play_sound(snd_change_mk, 10, false);
}
