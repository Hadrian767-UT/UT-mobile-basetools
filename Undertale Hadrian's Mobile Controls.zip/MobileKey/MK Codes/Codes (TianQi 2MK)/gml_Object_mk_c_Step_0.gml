for (i = 0; i < 4; i++)
{
    if (device_mouse_check_button_pressed(i, mb_right))
    {
        mouseX = device_mouse_x_to_gui(i);
        mouseY = device_mouse_y_to_gui(i);
        
        if (mouseX < 0)
        {
            if (global.isFeatureEnabled == 1)
            {
                global.isFeatureEnabled = 0;
                instance_destroy(obj_mk);
                audio_play_sound(Windows_Notify_Email, 10, false);
            }
            else if (global.isFeatureEnabled == 0)
            {
                global.isFeatureEnabled = 1;
                instance_create_depth(0, 0, depth, obj_mk);
                audio_play_sound(xbox_live_notification, 10, false);
            }
        }
    }
}

event_user(0);
