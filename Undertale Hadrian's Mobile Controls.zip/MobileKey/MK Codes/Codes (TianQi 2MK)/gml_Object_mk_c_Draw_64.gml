Siz = 1;
draw_set_font(th_ui);
draw_set_color(c_white);
col += 1;
c1 = make_color_hsv(col % 255, 255, 255);
c2 = make_color_hsv((col + 200) % 255, 255, 255);
c3 = make_color_hsv((col + 300) % 255, 255, 255);
c4 = make_color_hsv((col + 400) % 255, 255, 255);
draw_text_transformed_color(room_width - (string_width("fps: 00/00 ") * Siz), room_height - (string_height("fps: 00/00") * Siz), "fps: " + string(fps) + "/" + string(room_speed), Siz, Siz, 0, c1, c2, c3, c4, 1);
