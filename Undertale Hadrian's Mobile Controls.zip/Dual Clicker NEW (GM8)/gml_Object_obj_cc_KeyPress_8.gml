if (global.mbk == 0)
{
	global.mbk = 1;
	audio_play_sound(xbox_live_notification, 0, false);
}
else if (global.mbk == 1)
{
	global.mbk = 0;
	audio_play_sound(Windows_Notify_Email, 0, false);
}
