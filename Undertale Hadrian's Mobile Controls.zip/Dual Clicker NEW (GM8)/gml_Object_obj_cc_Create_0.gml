global.ui_cc = 1;
config_path = "CC.ini";

if (file_exists(config_path))
{
    ini_open(config_path);
    global.ui_cc = ini_read_real("Controller", "Changer", 1);
    ini_close();
}

if (global.ui_cc == 2)
    instance_create_depth(0, 0, -15998, obj_mk);
else if (global.ui_cc == 3)
    instance_create_depth(0, 0, -15998, obj_mobilecontrols);
else if (global.ui_cc == 4)
    instance_create_depth(0, 0, -15998, obj_mobilebuttons);
