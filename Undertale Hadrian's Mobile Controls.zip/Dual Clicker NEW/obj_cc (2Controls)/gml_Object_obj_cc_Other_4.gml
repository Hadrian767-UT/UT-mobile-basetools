if (global.ui_cc == 2 && !instance_exists(obj_mk))
{
    instance_create_depth(0, 0, -15998, obj_mk);
}
else if (global.ui_cc == 3 && !instance_exists(obj_mobilecontrols))
{
    instance_create_depth(0, 0, -15998, obj_mobilecontrols);
        
    with (obj_mobilecontrols)
    {
        if (!script_exists(scr_add_keys()))
            scr_add_keys();
    }
}
else if (global.ui_cc == 4 && !instance_exists(obj_mobilebuttons))
{
    instance_create_depth(0, 0, -15998, obj_mobilebuttons);
        
    with (obj_mobilebuttons)
    {
        if (!script_exists(scr_add_buttons()))
            scr_add_buttons();
    }
}
