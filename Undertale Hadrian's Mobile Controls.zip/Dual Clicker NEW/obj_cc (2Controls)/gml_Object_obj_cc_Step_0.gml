if (keyboard_check_pressed(47))
{
    if (cc == 1)
    {
        cc = 0;
        CC_Add("Dual Clicker enabled!");
    }
    else if (cc == 0)
    {
        cc = 1;
        CC_Add("Dual Clicker disabled!");
    }
    
    ini_open(game_path);
    ini_write_real("Game", "Ini", cc);
    ini_close();
}

if (cc == 0)
{
    if (device_mouse_x_to_gui(0) < 0 && mouse_check_button_pressed(mb_right))
    {
        with (obj_cc)
            event_perform(ev_keypress, vk_backspace);	
    }
}
