var left_side_x1 = -200;
var left_side_x2 = -1;
var left_side_y1 = -200;
var left_side_y2 = 680;
var right_side_x1 = 640;
var right_side_x2 = 840;
var right_side_y1 = -200;
var right_side_y2 = 680;
var mouse_in_left = device_mouse_x_to_gui(0) > left_side_x1 && device_mouse_x_to_gui(0) < left_side_x2 && device_mouse_y_to_gui(0) > left_side_y1 && device_mouse_y_to_gui(0) < left_side_y2;
var mouse_in_right = device_mouse_x_to_gui(0) > right_side_x1 && device_mouse_x_to_gui(0) < right_side_x2 && device_mouse_y_to_gui(0) > right_side_y1 && device_mouse_y_to_gui(0) < right_side_y2;

if (mouse_in_left && mouse_check_button_pressed(mb_left))
{
    if (last_side == "left" && (current_time - time_lastclick) < limit_time)
    {
        with (obj_cc)
            event_perform(ev_keypress, vk_backspace);
    }
    
    clicks_left += 1;
    last_side = "left";
    time_lastclick = current_time;
}

if (mouse_in_right && mouse_check_button_pressed(mb_left))
{
    clicks_right += 1;
    last_side = "right";
    time_lastclick = current_time;
}

if (mouse_in_left && mouse_check_button_pressed(mb_right))
{
    with (obj_cc)
        event_perform(ev_keypress, vk_backspace);
}
