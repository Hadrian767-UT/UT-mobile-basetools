if (keyboard_check_pressed(ord("V")))
{
    if (cc == 1)
    {
        instance_create_depth(0, 0, -15998, obj_controller_changer);
        cc = 0;
        audio_play_sound(snd_save, 0, false);
    }
    else if (cc == 0)
    {
        instance_destroy(obj_controller_changer);
        cc = 1;
        audio_play_sound(snd_item, 0, false);
    }
    
    ini_open(game_path);
    ini_write_real("Game", "Ini", cc);
    ini_close();
}
