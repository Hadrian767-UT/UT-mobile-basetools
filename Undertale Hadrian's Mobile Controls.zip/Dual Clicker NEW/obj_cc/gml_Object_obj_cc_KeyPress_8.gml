if (global.ui_cc == 1)
{
    global.ui_cc = 2;
    audio_play_sound(xbox_live_notification, 0, false);
    instance_create_depth(0, 0, -15998, obj_mk);
    CC_Add("Current: MobileKey By Crosu");
    
    with (obj_mobilecontrols)
    {
        virtual_key_delete(virtual_key_up);
        virtual_key_delete(virtual_key_down);
        virtual_key_delete(virtual_key_left);
        virtual_key_delete(virtual_key_right);
        virtual_key_delete(virtual_key_z);
        virtual_key_delete(virtual_key_x);
        virtual_key_delete(virtual_key_c);
        virtual_key_delete(virtual_key_zp);
        virtual_key_delete(virtual_key_xp);
        virtual_key_delete(virtual_key_cp);
        
        if (global.debug_legally == 1)
            virtual_key_delete(virtual_key_debugp);
        
        virtual_key_delete(virtual_key_dualp);
        virtual_key_delete(virtual_key_f2p);
        virtual_key_delete(virtual_key_analog);
        virtual_key_delete(virtual_key_analogp);
        virtual_key_delete(virtual_key_settings);
        
        if (global.debug_legally == 1)
            virtual_key_delete(virtual_key_debug);
        
        virtual_key_delete(virtual_key_dual);
        virtual_key_delete(virtual_key_f2);
    }
    
    with (obj_mobilebuttons)
    {
        virtual_key_delete(virtual_key_z);
        virtual_key_delete(virtual_key_x);
        virtual_key_delete(virtual_key_c);
        virtual_key_delete(virtual_key_r);
        virtual_key_delete(virtual_key_one);
        virtual_key_delete(virtual_key_two);
        virtual_key_delete(virtual_key_three);
        virtual_key_delete(virtual_key_four);
        virtual_key_delete(virtual_key_zp);
        virtual_key_delete(virtual_key_xp);
        virtual_key_delete(virtual_key_cp);
        
        if (global.debug_legally == 1)
            virtual_key_delete(virtual_key_debugp);
        
        virtual_key_delete(virtual_key_dualp);
        virtual_key_delete(virtual_key_rp);
        virtual_key_delete(virtual_key_onep);
        virtual_key_delete(virtual_key_twop);
        virtual_key_delete(virtual_key_threep);
        virtual_key_delete(virtual_key_fourp);
        
        if (global.debug_legally == 1)
            virtual_key_delete(virtual_key_debug);
        
        virtual_key_delete(virtual_key_dual);
    }
}
else if (global.ui_cc == 2)
{
    global.ui_cc = 3;
    audio_play_sound(xbox_live_notification, 0, false);
    instance_create_depth(0, 0, -15998, obj_mobilecontrols);
    CC_Add("Current: Mobile Controls By&GitMuslim");
    instance_destroy(obj_mk);
    
    with (obj_mobilecontrols)
	{
	    if (!script_exists(scr_add_keys()))
            scr_add_keys();
	}		
}
else if (global.ui_cc == 3)
{
    global.ui_cc = 4;
    audio_play_sound(xbox_live_notification, 0, false);
    instance_create_depth(0, 0, -15998, obj_mobilebuttons);
    CC_Add("Current: Mobile Buttons By&Ilka MP");
    
    with (obj_mobilecontrols)
    {
        instance_destroy();
        virtual_key_delete(virtual_key_up);
        virtual_key_delete(virtual_key_down);
        virtual_key_delete(virtual_key_left);
        virtual_key_delete(virtual_key_right);
        virtual_key_delete(virtual_key_z);
        virtual_key_delete(virtual_key_x);
        virtual_key_delete(virtual_key_c);
        virtual_key_delete(virtual_key_zp);
        virtual_key_delete(virtual_key_xp);
        virtual_key_delete(virtual_key_cp);
        
        if (global.debug_legally == 1)
            virtual_key_delete(virtual_key_debugp);
        
        virtual_key_delete(virtual_key_dualp);
        virtual_key_delete(virtual_key_f2p);
        virtual_key_delete(virtual_key_analog);
        virtual_key_delete(virtual_key_analogp);
        virtual_key_delete(virtual_key_settings);
        
        if (global.debug_legally == 1)
            virtual_key_delete(virtual_key_debug);
        
        virtual_key_delete(virtual_key_dual);
        virtual_key_delete(virtual_key_f2);
    }
    
    with (obj_mobilebuttons)
	{
	    if (!script_exists(scr_add_buttons()))
            scr_add_buttons();
	}		
}
else if (global.ui_cc == 4)
{
    global.ui_cc = 1;
    audio_play_sound(Windows_Notify_Email, 0, false);
    CC_Add("Current: Disabled");
    
    with (obj_mobilebuttons)
    {
        instance_destroy();
        virtual_key_delete(virtual_key_z);
        virtual_key_delete(virtual_key_x);
        virtual_key_delete(virtual_key_c);
        virtual_key_delete(virtual_key_r);
        virtual_key_delete(virtual_key_one);
        virtual_key_delete(virtual_key_two);
        virtual_key_delete(virtual_key_three);
        virtual_key_delete(virtual_key_four);
        virtual_key_delete(virtual_key_zp);
        virtual_key_delete(virtual_key_xp);
        virtual_key_delete(virtual_key_cp);
        
        if (global.debug_legally == 1)
            virtual_key_delete(virtual_key_debugp);
        
        virtual_key_delete(virtual_key_dualp);
        virtual_key_delete(virtual_key_rp);
        virtual_key_delete(virtual_key_onep);
        virtual_key_delete(virtual_key_twop);
        virtual_key_delete(virtual_key_threep);
        virtual_key_delete(virtual_key_fourp);
        
        if (global.debug_legally == 1)
            virtual_key_delete(virtual_key_debug);
        
        virtual_key_delete(virtual_key_dual);
    }
}

ini_open(config_path);
ini_write_real("Controller", "Changer", global.ui_cc);
ini_close();
