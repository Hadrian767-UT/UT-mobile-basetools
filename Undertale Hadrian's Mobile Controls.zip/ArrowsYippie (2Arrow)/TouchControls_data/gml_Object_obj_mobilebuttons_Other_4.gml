if (global.debug_legally == 1)
    virtual_key_debugp = virtual_key_add(debugx, debugy, 19 * button_scale, 25 * button_scale, 95);

virtual_key_dualp = virtual_key_add(dualx, dualy, 19 * button_scale, 25 * button_scale, 96);
virtual_key_zp = virtual_key_add(zx, zy, 27 * button_scale, 29 * button_scale, 125);
virtual_key_xp = virtual_key_add(xx, xy, 27 * button_scale, 29 * button_scale, 124);
virtual_key_cp = virtual_key_add(cx, cy, 27 * button_scale, 29 * button_scale, 94);
virtual_key_rp = virtual_key_add(rx, ry, 19 * button_scale, 25 * button_scale, 106);
virtual_key_onep = virtual_key_add(onex, oney, 27 * button_scale, 29 * button_scale, 222);
virtual_key_twop = virtual_key_add(twox, twoy, 27 * button_scale, 29 * button_scale, 219);
virtual_key_threep = virtual_key_add(threex, threey, 27 * button_scale, 29 * button_scale, 220);
virtual_key_fourp = virtual_key_add(fourx, foury, 27 * button_scale, 29 * button_scale, 107);
virtual_key_fivep = virtual_key_add(fivex, fivey, 27 * button_scale, 29 * button_scale, 223);
virtual_key_sixp = virtual_key_add(sixx, sixy, 27 * button_scale, 29 * button_scale, 224);
virtual_key_sevenp = virtual_key_add(sevenx, seveny, 27 * button_scale, 29 * button_scale, 225);
virtual_key_eightp = virtual_key_add(eightx, eighty, 27 * button_scale, 29 * button_scale, 226);
virtual_key_settings = virtual_key_add(settingsx, settingsy, 19 * button_scale, 25 * button_scale, 92);

if (edit != 0)
    exit;

virtual_key_z = virtual_key_add(zx, zy, 27 * button_scale, 29 * button_scale, 90);
virtual_key_x = virtual_key_add(xx, xy, 27 * button_scale, 29 * button_scale, 88);
virtual_key_c = virtual_key_add(cx, cy, 27 * button_scale, 29 * button_scale, 67);

if (global.debug_legally == 1)
    virtual_key_debug = virtual_key_add(debugx, debugy, 19 * button_scale, 25 * button_scale, 84);

virtual_key_dual = virtual_key_add(dualx, dualy, 19 * button_scale, 25 * button_scale, 86);
virtual_key_r = virtual_key_add(rx, ry, 19 * button_scale, 25 * button_scale, 113);
virtual_key_one = virtual_key_add(onex, oney, 27 * button_scale, 29 * button_scale, 38);
virtual_key_two = virtual_key_add(twox, twoy, 27 * button_scale, 29 * button_scale, 40);
virtual_key_three = virtual_key_add(threex, threey, 27 * button_scale, 29 * button_scale, 37);
virtual_key_four = virtual_key_add(fourx, foury, 27 * button_scale, 29 * button_scale, 39);
virtual_key_five = virtual_key_add(fivex, fivey, 27 * button_scale, 29 * button_scale, 87);
virtual_key_six = virtual_key_add(sixx, sixy, 27 * button_scale, 29 * button_scale, 83);
virtual_key_seven = virtual_key_add(sevenx, seveny, 27 * button_scale, 29 * button_scale, 65);
virtual_key_eight = virtual_key_add(eightx, eighty, 27 * button_scale, 29 * button_scale, 68);
