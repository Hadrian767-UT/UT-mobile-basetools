if (keyboard_check(126))
{
    if (device_mouse_x_to_gui(0) >= analog_posx && device_mouse_x_to_gui(0) <= (analog_posx + (59 * analog_scale)))
        analog_center_x = device_mouse_x_to_gui(0) - (21 * analog_scale);
    
    if (device_mouse_y_to_gui(0) >= analog_posy && device_mouse_y_to_gui(0) <= (analog_posy + (59 * analog_scale)))
        analog_center_y = device_mouse_y_to_gui(0) - (21 * analog_scale);
}
else
{
    analog_center_x = (analog_posx + ((59 * analog_scale) / 2)) - ((41 * analog_scale) / 2);
    analog_center_y = (analog_posy + ((59 * analog_scale) / 2)) - ((41 * analog_scale) / 2);
}

if (keyboard_check_pressed(92))
{
    edit += 1;
    
    if (edit == 1)
    {
        black_fade = 0.4;
        text_black_fade = 0.9;
    }
    else if (edit == 2)
    {
        virtual_key_delete(virtual_key_z);
        virtual_key_delete(virtual_key_x);
        virtual_key_delete(virtual_key_c);
        virtual_key_delete(virtual_key_r);
        virtual_key_delete(virtual_key_one);
        virtual_key_delete(virtual_key_two);
        virtual_key_delete(virtual_key_three);
        virtual_key_delete(virtual_key_four);
        virtual_key_delete(virtual_key_five);
        virtual_key_delete(virtual_key_six);
        virtual_key_delete(virtual_key_seven);
        virtual_key_delete(virtual_key_eight);
        virtual_key_delete(virtual_key_zp);
        virtual_key_delete(virtual_key_xp);
        virtual_key_delete(virtual_key_cp);
        
        if (global.debug_legally == 1)
            virtual_key_delete(virtual_key_debugp);
        
        virtual_key_delete(virtual_key_dualp);
        virtual_key_delete(virtual_key_rp);
        virtual_key_delete(virtual_key_onep);
        virtual_key_delete(virtual_key_twop);
        virtual_key_delete(virtual_key_threep);
        virtual_key_delete(virtual_key_fourp);
        virtual_key_delete(virtual_key_fivep);
        virtual_key_delete(virtual_key_sixp);
        virtual_key_delete(virtual_key_sevenp);
        virtual_key_delete(virtual_key_eightp);
        virtual_key_delete(virtual_key_settings);
        
        if (global.debug_legally == 1)
            virtual_key_delete(virtual_key_debug);
        
        virtual_key_delete(virtual_key_dual);
        ini_open("touchconfigarrows.ini");
        ini_write_real("CONFIG", "zx", zx);
        ini_write_real("CONFIG", "zy", zy);
        ini_write_real("CONFIG", "xx", xx);
        ini_write_real("CONFIG", "xy", xy);
        ini_write_real("CONFIG", "cx", cx);
        ini_write_real("CONFIG", "cy", cy);
        
        if (global.debug_legally == 1)
        {
            ini_write_real("CONFIG", "debugx", debugx);
            ini_write_real("CONFIG", "debugy", debugy);
        }
        
        ini_write_real("CONFIG", "dualx", dualx);
        ini_write_real("CONFIG", "dualy", dualy);
        ini_write_real("CONFIG", "rx", rx);
        ini_write_real("CONFIG", "ry", ry);
        ini_write_real("CONFIG", "settingsx", settingsx);
        ini_write_real("CONFIG", "settingsy", settingsy);
        ini_write_real("CONFIG", "onex", onex);
        ini_write_real("CONFIG", "oney", oney);
        ini_write_real("CONFIG", "twox", twox);
        ini_write_real("CONFIG", "twoy", twoy);
        ini_write_real("CONFIG", "threex", threex);
        ini_write_real("CONFIG", "threey", threey);
        ini_write_real("CONFIG", "fourx", fourx);
        ini_write_real("CONFIG", "foury", foury);
        ini_write_real("CONFIG", "fivex", fivex);
        ini_write_real("CONFIG", "fivey", fivey);
        ini_write_real("CONFIG", "sixx", sixx);
        ini_write_real("CONFIG", "sixy", sixy);
        ini_write_real("CONFIG", "sevenx", sevenx);
        ini_write_real("CONFIG", "seveny", seveny);
        ini_write_real("CONFIG", "eightx", eightx);
        ini_write_real("CONFIG", "eighty", eighty);
        ini_write_real("CONFIG", "analog_posx", analog_posx);
        ini_write_real("CONFIG", "analog_posy", analog_posy);
        ini_write_real("CONFIG", "button_scale", button_scale);
        ini_write_real("CONFIG", "analog_scale", analog_scale);
        ini_write_real("CONFIG", "joystick_type", joystick_type);
        ini_write_real("CONFIG", "controls_opacity", controls_opacity);
        ini_close();
        black_fade = 0;
        text_black_fade = 0;
        edit = 0;
        scr_add_buttons();
    }
}

if (edit == 0)
    exit;

virtual_key_delete(virtual_key_z);
virtual_key_delete(virtual_key_x);
virtual_key_delete(virtual_key_c);

if (global.debug_legally == 1)
    virtual_key_delete(virtual_key_debug);

virtual_key_delete(virtual_key_dual);
virtual_key_delete(virtual_key_r);
virtual_key_delete(virtual_key_one);
virtual_key_delete(virtual_key_two);
virtual_key_delete(virtual_key_three);
virtual_key_delete(virtual_key_four);
virtual_key_delete(virtual_key_five);
virtual_key_delete(virtual_key_six);
virtual_key_delete(virtual_key_seven);
virtual_key_delete(virtual_key_eight);
virtual_key_delete(virtual_key_zp);
virtual_key_delete(virtual_key_xp);
virtual_key_delete(virtual_key_cp);

if (global.debug_legally == 1)
    virtual_key_delete(virtual_key_debugp);

virtual_key_delete(virtual_key_dualp);
virtual_key_delete(virtual_key_rp);
virtual_key_delete(virtual_key_onep);
virtual_key_delete(virtual_key_twop);
virtual_key_delete(virtual_key_threep);
virtual_key_delete(virtual_key_fourp);
virtual_key_delete(virtual_key_fivep);
virtual_key_delete(virtual_key_sixp);
virtual_key_delete(virtual_key_sevenp);
virtual_key_delete(virtual_key_eightp);
virtual_key_delete(virtual_key_settings);
scr_add_buttons();

if (keyboard_check(vk_multiply))
{
    rx = device_mouse_x_to_gui(0) - ((19.5 * button_scale) / 1.5);
    ry = device_mouse_y_to_gui(0) - ((18 * button_scale) / 1.5);
}

if (keyboard_check(125))
{
    zx = device_mouse_x_to_gui(0) - (19.5 * button_scale);
    zy = device_mouse_y_to_gui(0) - (18 * button_scale);
}

if (keyboard_check(222))
{
    onex = device_mouse_x_to_gui(0) - (19.5 * button_scale);
    oney = device_mouse_y_to_gui(0) - (18 * button_scale);
}

if (keyboard_check(219))
{
    twox = device_mouse_x_to_gui(0) - (19.5 * button_scale);
    twoy = device_mouse_y_to_gui(0) - (18 * button_scale);
}

if (keyboard_check(220))
{
    threex = device_mouse_x_to_gui(0) - (19.5 * button_scale);
    threey = device_mouse_y_to_gui(0) - (18 * button_scale);
}

if (keyboard_check(vk_add))
{
    fourx = device_mouse_x_to_gui(0) - (19.5 * button_scale);
    foury = device_mouse_y_to_gui(0) - (18 * button_scale);
}

if (keyboard_check(223))
{
    fivex = device_mouse_x_to_gui(0) - (19.5 * button_scale);
    fivey = device_mouse_y_to_gui(0) - (18 * button_scale);
}

if (keyboard_check(224))
{
    sixx = device_mouse_x_to_gui(0) - (19.5 * button_scale);
    sixy = device_mouse_y_to_gui(0) - (18 * button_scale);
}

if (keyboard_check(225))
{
    sevenx = device_mouse_x_to_gui(0) - (19.5 * button_scale);
    seveny = device_mouse_y_to_gui(0) - (18 * button_scale);
}

if (keyboard_check(226))
{
    eightx = device_mouse_x_to_gui(0) - (19.5 * button_scale);
    eighty = device_mouse_y_to_gui(0) - (18 * button_scale);
}

if (keyboard_check(124))
{
    xx = device_mouse_x_to_gui(0) - (19.5 * button_scale);
    xy = device_mouse_y_to_gui(0) - (18 * button_scale);
}

if (keyboard_check(94))
{
    cx = device_mouse_x_to_gui(0) - (19.5 * button_scale);
    cy = device_mouse_y_to_gui(0) - (18 * button_scale);
}

if (keyboard_check(95) && global.debug_legally == 1)
{
    debugx = device_mouse_x_to_gui(0) - ((19.5 * button_scale) / 1.5);
    debugy = device_mouse_y_to_gui(0) - ((18 * button_scale) / 1.5);
}

if (keyboard_check(vk_numpad0))
{
    dualx = device_mouse_x_to_gui(0) - ((19.5 * button_scale) / 1.5);
    dualy = device_mouse_y_to_gui(0) - ((18 * button_scale) / 1.5);
}

if (device_mouse_x_to_gui(0) >= (joystick_type ? 120.5 : 459.5) && device_mouse_y_to_gui(0) >= 75 && device_mouse_x_to_gui(0) <= (joystick_type ? 140.5 : 469.5) && device_mouse_y_to_gui(0) <= 95 && mouse_check_button_pressed(mb_left))
{
    if (button_scale > 1)
        button_scale -= 0.1;
}

if (device_mouse_x_to_gui(0) >= (joystick_type ? 195.5 : 531.5) && device_mouse_y_to_gui(0) >= 75 && device_mouse_x_to_gui(0) <= (joystick_type ? 205.5 : 541.5) && device_mouse_y_to_gui(0) <= 95 && mouse_check_button_pressed(mb_left))
{
    if (button_scale < 4)
        button_scale += 0.1;
}

if (device_mouse_x_to_gui(0) >= (joystick_type ? 120.5 : 459.5) && device_mouse_y_to_gui(0) >= 145 && device_mouse_x_to_gui(0) <= (joystick_type ? 140.5 : 479.5) && device_mouse_y_to_gui(0) <= 165 && mouse_check_button_pressed(mb_left))
{
    if (analog_scale > 1)
        analog_scale -= 0.1;
}

if (device_mouse_x_to_gui(0) >= (joystick_type ? 210.5 : 124) && device_mouse_y_to_gui(0) >= 145 && device_mouse_x_to_gui(0) <= (joystick_type ? 230.5 : 144) && device_mouse_y_to_gui(0) <= 165 && mouse_check_button_pressed(mb_left))
{
    if (analog_scale < 4)
        analog_scale += 0.1;
}

if (device_mouse_x_to_gui(0) >= (joystick_type ? 120.5 : 531.5) && device_mouse_y_to_gui(0) >= 145 && device_mouse_x_to_gui(0) <= (joystick_type ? 140.5 : 541.5) && device_mouse_y_to_gui(0) <= 165 && mouse_check_button_pressed(mb_left))
{
    settings_pressed = 1;
    joystick_type = 0;
}

if (device_mouse_x_to_gui(0) >= (joystick_type ? 192.5 : 531.5) && device_mouse_y_to_gui(0) >= 145 && device_mouse_x_to_gui(0) <= (joystick_type ? 202.5 : 541.5) && device_mouse_y_to_gui(0) <= 165 && mouse_check_button_pressed(mb_left))
{
    settings_pressed = 1;
    joystick_type = 1;
}

if (device_mouse_x_to_gui(0) >= (joystick_type ? 120.5 : 459.5) && device_mouse_y_to_gui(0) >= 213 && device_mouse_x_to_gui(0) <= (joystick_type ? 130.5 : 469.5) && device_mouse_y_to_gui(0) <= 233 && mouse_check_button_pressed(mb_left))
{
    if (controls_opacity > 0)
        controls_opacity -= 0.05;
}

if (device_mouse_x_to_gui(0) >= (joystick_type ? 192.5 : 531.5) && device_mouse_y_to_gui(0) >= 213 && device_mouse_x_to_gui(0) <= (joystick_type ? 202.5 : 541.5) && device_mouse_y_to_gui(0) <= 233 && mouse_check_button_pressed(mb_left))
{
    if (controls_opacity < 1)
        controls_opacity += 0.05;
}

if (device_mouse_x_to_gui(0) >= 241 && device_mouse_y_to_gui(0) >= 412.25 && device_mouse_x_to_gui(0) <= 399 && device_mouse_y_to_gui(0) <= 436.25 && mouse_check_button_pressed(mb_left))
{
    settings_pressed = 1;
    button_scale = 3;
    controls_opacity = 0.5;
    
    if (joystick_type == 1)
    {
        do1type = 0;
        do0type = 1;
    }
    else if (joystick_type == 0)
    {
        do1type = 1;
        do0type = 0;
    }
}

if (settings_pressed == 1 && joystick_type == 1 && do1type == 0)
{
    do0type = 0;
    do1type = 1;
    onex = 623;
    oney = 200;
    twox = 623;
    twoy = 340;
    threex = 559;
    threey = 270;
    fourx = 683;
    foury = 270;
    fivex = 13;
    fivey = 200;
    sixx = 13;
    sixy = 340;
    sevenx = -51;
    seveny = 270;
    eightx = 73;
    eighty = 270;
    zx = 26;
    zy = 115;
    xx = -90;
    xy = 115;
    cx = -34;
    cy = 30;
    settingsx = 578;
    settingsy = 5;
    rx = 574;
    ry = 86;
    debugx = 504;
    debugy = 5;
    dualx = 504;
    dualy = 86;
    actual_joy_type = 1;
}

if (settings_pressed == 1 && joystick_type == 0 && do0type == 0)
{
    do0type = 1;
    do1type = 0;
    onex = -30;
    oney = 200;
    twox = -30;
    twoy = 340;
    threex = -90;
    threey = 270;
    fourx = 34;
    foury = 270;
    fivex = 580;
    fivey = 200;
    sixx = 580;
    sixy = 340;
    sevenx = 520;
    seveny = 270;
    eightx = 644;
    eighty = 270;
    zx = 567;
    zy = 115;
    xx = 683;
    xy = 115;
    cx = 627;
    cy = 30;
    settingsx = 5;
    settingsy = 5;
    rx = 1;
    ry = 86;
    debugx = 75;
    debugy = 5;
    dualx = 75;
    dualy = 86;
    actual_joy_type = 0;
}
